
require("./PromptBuddy.module.css");
const styles = {
  promptBuddy: 'promptBuddy_6e7a6284',
  welcome: 'welcome_6e7a6284',
  welcomeImage: 'welcomeImage_6e7a6284',
  links: 'links_6e7a6284'
};

export default styles;
