declare const styles: {
    promptBuddy: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=PromptBuddy.module.scss.d.ts.map