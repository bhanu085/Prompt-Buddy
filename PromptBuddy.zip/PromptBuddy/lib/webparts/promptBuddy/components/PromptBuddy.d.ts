/// <reference types="react" />
import type { IPromptBuddyProps } from "./IPromptBuddyProps";
export default function PromptBuddy(props: IPromptBuddyProps): JSX.Element;
//# sourceMappingURL=PromptBuddy.d.ts.map