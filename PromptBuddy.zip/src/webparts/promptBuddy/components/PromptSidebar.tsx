// @ts-nocheck
import * as React from "react";
import styles from "./PromptSidebar.module.scss";
import { Button, Text } from "@fluentui/react-components";
import {
  AddRegular,
  DocumentRegular,
  GlobeRegular,
  PaintBrushRegular,
  TableRegular,
  FormRegular,
  ArrowRepeatAllRegular,
  NotebookRegular,
  MailRegular,
  PeopleCommunityRegular,
} from "@fluentui/react-icons";

export default function PromptSidebar({ promptCategories,ShowSubmitButton, selectedCategory, onSelectCategory, onSubmitPrompt,showSubmitForm }) {
  console.log("showsubmitbutton in PromptSidebar:" , ShowSubmitButton);
  // const categories = [
  //   { title: "Copilot (M365)", icon: <DocumentRegular />, colorClass: styles.iconCopilotM365 },
  //   { title: "Copilot (web)", icon: <GlobeRegular />, colorClass: styles.iconCopilotWeb },
  //   { title: "Designer", icon: <PaintBrushRegular />, colorClass: styles.iconDesigner },
  //   { title: "Excel", icon: <TableRegular />, colorClass: styles.iconExcel },
  //   { title: "Forms", icon: <FormRegular />, colorClass: styles.iconForms },
  //   { title: "Loop", icon: <ArrowRepeatAllRegular />, colorClass: styles.iconLoop },
  //   { title: "OneNote", icon: <NotebookRegular />, colorClass: styles.iconOneNote },
  //   { title: "Outlook", icon: <MailRegular />, colorClass: styles.iconOutlook },
  //   { title: "Power Apps", icon: <PaintBrushRegular />, colorClass: styles.iconPowerApps },
  //   { title: "Power Automate", icon: <ArrowRepeatAllRegular />, colorClass: styles.iconPowerAutomate },
  //   { title: "PowerPoint", icon: <DocumentRegular />, colorClass: styles.iconPowerPoint },
  //   { title: "Teams", icon: <PeopleCommunityRegular />, colorClass: styles.iconTeams },
  // ];
// Dynamically load from prop; fallback to static if empty
//console.log("PromptSidebar received categories:", promptCategories);
const categories = promptCategories?.length
  ? promptCategories.map((cat) => {
      // convert the Icon name (string from SharePoint) to the actual Fluent icon
      const iconMap = {
        DocumentRegular: <DocumentRegular aria-label="Document" />,
        GlobeRegular: <GlobeRegular aria-label="Globe" />,
        PaintBrushRegular: <PaintBrushRegular aria-label="Paint Brush" />,
        TableRegular: <TableRegular aria-label="Table" />,
        FormRegular: <FormRegular aria-label="Form" />,
        ArrowRepeatAllRegular: <ArrowRepeatAllRegular aria-label="Arrow Repeat All" />,
        NotebookRegular: <NotebookRegular aria-label="Notebook" />,
        MailRegular: <MailRegular aria-label="Mail" />,
        PeopleCommunityRegular: <PeopleCommunityRegular aria-label="People Community" />,
      };

      return {
        title: cat.title,
        description: cat.description,
        prompts: cat.prompts,
        icon: cat.icon || <DocumentRegular aria-label="Document" />, // default icon
        color: cat.gradient || "#ccc",
      };
    })
  : [];
//console.log("Using categories in PromptSidebar:", categories);
  return (
    <div className={styles.sidebar}>
      {/* Submit button */}
      
        {showSubmitForm ? (
        <div className={styles.submitTitle}>Submit Prompts</div>
        ) : (
          <Button
            appearance="primary"
            // disabled={!ShowSubmitButton}
            style={{ display: ShowSubmitButton ? "inline-flex" : "none" }}
            icon={<AddRegular aria-label="Add" />}
            className={styles.submitButton}
            onClick={() => onSubmitPrompt?.()}
          >
            Submit a prompt
          </Button>
        )}
     


      {/* Category list */}
      <div className={styles.categoryList}>
        {/* {categories.map((cat) => (
          <div
            key={cat.title}
            className={`${styles.categoryItem} ${
              selectedCategory?.title === cat.title ? styles.active : ""
            }`}
            onClick={() => onSelectCategory(cat)}
          >
            <div className={`${styles.iconBox} ${cat.colorClass}`}>
              {cat.icon}
            </div>
            <Text className={styles.label}>{cat.title}</Text>
          </div>
        ))} */}
        {categories.map((cat) => (
          <div
            key={cat.title}
            className={`${styles.categoryItem} ${
              selectedCategory?.title === cat.title ? styles.active : ""
            }`}
            onClick={() => onSelectCategory(cat)}
          >
            <div className={styles.categoryLeft}>
              <div className={styles.iconBox} style={{ background: cat.color }}>
                {cat.icon}
              </div>
              <Text className={styles.label}>{cat.title}</Text>
            </div>
            {/* {selectedCategory?.title === cat.title && ( */}
              <div className={styles.countBadge}>{cat.prompts}</div>
            {/* )} */}
          </div>            
        ))}
      </div>
    </div>
  );
}
