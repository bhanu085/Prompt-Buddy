// @ts-nocheck
import * as React from "react";
import styles from "./PromptBuddy.module.scss";
import type { IPromptBuddyProps } from "./IPromptBuddyProps";
import {
  Avatar,
  Text,
  Input,
  Button,
  Card,
} from "@fluentui/react-components";
import {
  PeopleCommunityRegular,
  LightbulbFilamentRegular,
  SparkleRegular,
  HeartRegular,
  SearchRegular,
  DocumentRegular,
  GlobeRegular,
  PaintBrushRegular,
  TableRegular,
  FormRegular,
  ArrowRepeatAllRegular,
  NotebookRegular,
  MailRegular,
  SparkleFilled,
} from "@fluentui/react-icons";

import PromptDetails from "./PromptDetails";

import { spfi, SPFx } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";


export default function PromptBuddy(props: IPromptBuddyProps): JSX.Element {
  const [selectedCategory, setSelectedCategory] = React.useState(null);
  const [promptCategories, setPromptCategories] = React.useState([]);
  const [categories, setCategories] = React.useState([]);
  const [gcategories, setgCategories] = React.useState([]);
  const [pmtCategories, setPmtCategories] = React.useState([]);
  const [pCategories, setpCategories] = React.useState([]);
  const [fetchPrompts, setfetchPrompts] = React.useState([]);
  const [gDeptPrompts, setgDeptPrompts] = React.useState([]);
  const [departments, setDepartments] = React.useState([]);
  const [activeToolbar, setActiveToolbar] = React.useState("all");
  const [configItems, setConfigItems] = React.useState(null);
  const [userDepartment, setUserDepartment] = React.useState("");
  const [userCostCenters, setUserCostCenters] = React.useState([]);
  const [userLikedPrompts, setUserLikedPrompts] = React.useState<string[]>([]);
  const [favoritePrompts, setFavoritePrompts] = React.useState<string[]>([]);
  const [topContributors, setTopContributors] = React.useState([]);
  const [topPrompts, setTopPrompts] = React.useState([]);
  const [newPromptsList, setNewPromptsList] = React.useState([]);

  const [searchText, setSearchText] = React.useState("");

  const sp = React.useMemo(() => spfi().using(SPFx(props.context)), [props.context]);

  const toolbarItems = [
  { key: "all", label: "All" },
  { key: "favourites", label: "My Favourites" },
  { key: "likes", label: "My Likes" },
  { key: "prompts", label: "My Prompts" },
  { key: "categories", label: "Categories" },
  { key: "apps", label: "Apps" },
  { key: "departments", label: "Departments" },
];


  const iconMap = {
    GlobeRegular: <GlobeRegular aria-label="Globe" />,
    SparkleRegular: <SparkleRegular aria-label="Sparkle" />,
    PeopleCommunityRegular: <PeopleCommunityRegular aria-label="People" />,
    DocumentRegular: <DocumentRegular aria-label="Document" />,
    ArrowRepeatAllRegular: <ArrowRepeatAllRegular aria-label="Arrow" />,
    PaintBrushRegular: <PaintBrushRegular aria-label="PaintBrush" />,
    LightbulbFilamentRegular: <LightbulbFilamentRegular aria-label="Lightbulb" />,
    MailRegular: <MailRegular aria-label="Mail" />,
    NotebookRegular: <NotebookRegular aria-label="Notebook" />,
    TableRegular: <TableRegular aria-label="Table" />,
    FormRegular: <FormRegular aria-label="Form" />,
    SparkleFilled: <SparkleFilled aria-label="SparkleFilled" />,
  };

  const getSP = (context?: any) => {
    try {
      if (context) return spfi().using(SPFx(context));
      return spfi("https://test.sharepoint.com");
    } catch {
      return spfi("https://test.sharepoint.com");
    }
  };

  // -------------------------
  // Load User Profile
  // -------------------------
  React.useEffect(() => {
    const loadProfile = async () => {
      const spInstance = spfi().using(SPFx(props.context));
      const profile = await spInstance.profiles.myProperties();
      console.log("User profile properties:", profile);
      const propsArray = profile.UserProfileProperties || [];

      const getProp = (key: string) =>
        propsArray.find((p: any) => p.Key === key)?.Value || "";

      const department = getProp("pncUCustom08");
      //const department = getProp("Department");
      const ccRaw = getProp("pncUCustom07");
      //const ccRaw = getProp("SPS-PictureExchangeSyncState");

      setUserDepartment(department);

      const ccList = ccRaw
        ? ccRaw.split(";").map((s) => s.trim()).filter(Boolean)
        : [];

      setUserCostCenters(ccList);
    };

    loadProfile();
  }, []);
  React.useEffect(() => {
    const loadUserPromptSummary = async () => {
      try {
        const spInstance = spfi().using(SPFx(props.context));
        const currentUser =
          props.context.pageContext.user.email ||
          props.context.pageContext.user.loginName;

        const items = await spInstance.web.lists
          .getByTitle("UserPromptSummary")
          .items.filter(`Title eq '${currentUser}'`)
          .top(1)();

        if (items.length > 0) {
          const summary = items[0];

          const liked = summary.PromptsLiked
            ? summary.PromptsLiked.split(/[;,]/).map((x) => x.trim()).filter(Boolean)
            : [];

          const fav = summary.FavoritePrompts
            ? summary.FavoritePrompts.split(/[;,]/).map((x) => x.trim()).filter(Boolean)
            : [];

          setUserLikedPrompts(liked);
          setFavoritePrompts(fav);

          console.log("❤️ Liked prompts:", liked);
          console.log("⭐ Favorite prompts:", fav);
        }
      } catch (err) {
        console.error("❌ Error loading user summary:", err);
      }
    };

    loadUserPromptSummary();
  }, []);
  const getConfigItems = async (sp) => {
  try {
    const items = await sp.web.lists
      .getByTitle("Config")
      .items.select("Title", "Value")
      .top(5000)();

    // Convert to a key-value object for easy access
    const configMap = items.reduce((acc, item) => {
      acc[item.Title] = item.Value;
      return acc;
    }, {});

    console.log("Config values:", configMap);
    return configMap;
  } catch (err) {
    console.error("❌ Error fetching Config items:", err);
    throw err;
  }
};

React.useEffect(() => {
  const sp = spfi().using(SPFx(props.context));
  getConfigItems(sp).then(setConfigItems);
}, []);


  // -------------------------
  // Main Load (Categories + Departments + Prompts)
  // -------------------------
  React.useEffect(() => {
    const fetchAll = async () => {
      try {
        const spInstance = getSP(props.context);

        // Load categories + departments
        const [catItems,cateItems, deptItems] = await Promise.all([
          spInstance.web.lists
            .getByTitle("Category")
            .items.select("Title", "Description", "Icon", "Color")
            .top(200)(),
          spInstance.web.lists
            .getByTitle("Categories")
            .items.select("Title", "Description", "Icon", "Color")
            .top(200)(),
          spInstance.web.lists
            .getByTitle("Departments")
            .items.select("Title", "Description", "Icon", "Color", "CostCenters")
            .top(500)(),
        ]);
        
        console.log("Loaded raw categories:", catItems);
        const categoryMap = catItems.map((item) => ({
          title: item.Title,
          description: item.Description,
          prompts: 0,
          icon: iconMap[item.Icon] || <DocumentRegular aria-label="Document" />,
          gradient:
            item.Color ||
            "linear-gradient(135deg,#3B4CCA 0%,#657BEA 60%,#A4C8FF 100%)",
        }));        
        setpCategories(categoryMap);
        const categoriesMap = cateItems.map((item) => ({
          title: item.Title,
          description: item.Description,
          prompts: 0,
          icon: iconMap[item.Icon] || <DocumentRegular aria-label="Document" />,
          gradient:
            item.Color ||
            "linear-gradient(135deg,#3B4CCA 0%,#657BEA 60%,#A4C8FF 100%)",
        }));
        const deptMap = deptItems.map((d) => ({
          title: d.Title,
          description: d.Description,
          costCenters: d.CostCenters || "",
          prompts: 0,
          icon: iconMap[d.Icon] || <PeopleCommunityRegular aria-label="People" />,
          gradient:
            d.Color ||
            "linear-gradient(135deg,#0078D4 0%,#4F86F7 100%)",
        }));

        setPromptCategories(categoryMap);
        setCategories(categoriesMap);
        setDepartments(deptMap);
        console.log("Loaded categories:", categoryMap);
        console.log("Loaded scategories:", categoriesMap);
        // Load all prompts unfiltered
        const allPrompts = await spInstance.web.lists
          .getByTitle("Prompts")
          .items.select(
            "Id",
            "Title",
            "Description",
            "Prompt",
            "Tags",
            "Status",
            "Category",
            "Categories",
            "Departments",
            "LikesCount",
            "SharingCount",
            "CopyCount",
            "TeamsShared",
            "TIPS",
            "ROI",
            "ETS",
            "ImageUrl",
            "Created",
            "Modified",
            "Author/Title",
            "Editor/Title",
            "Attachments",
            "AttachmentFiles"
          )
          .expand("Author", "Editor", "AttachmentFiles")
          .top(500)();                       

        const loggedInUser = props.context.pageContext.user.displayName;
       
        const approvedEveryone = allPrompts.filter(
          (p) =>
            p.Status === "Approved" &&
            (p.Departments || "").includes("All")
        );
        console.log("Approved for Everyone prompts:", approvedEveryone);
        const createdByMe = allPrompts.filter((p) => {
          const isMine = p.Author?.Title === loggedInUser;
          const isApprovedAndEveryone =
            (p.Status || "").trim() === "Approved" &&
            (p.Departments || "").trim() === "All";

          return isMine && !isApprovedAndEveryone;
        });
        console.log("Prompts created by me:", createdByMe);

        
        let filtered = [...approvedEveryone, ...createdByMe];
        console.log("Initial filtered prompts:", filtered);
        filtered = filtered.filter((p) => {
          if ((p.Departments || "").includes("All")) return true;

          const promptDeptList = (p.Departments || "")
            .split(";")
            .map((x) => x.trim());
          
          const matchingDepts = deptMap.filter((d) => {
            const dCC = (d.costCenters || "")
              .split("~")
              .map((x) => x.trim());
            return dCC.some((cc) => userCostCenters.includes(cc));
          });
          
          const matchingDeptNames = matchingDepts.map((d) => d.title);
          return promptDeptList.some((pd) => matchingDeptNames.includes(pd));
          
        });
        console.log("Filtered prompts after department check:", filtered);
        const approvedPrompts = filtered.filter(p => p.Status === "Approved");
        const contributorCounts = {};
        approvedPrompts.forEach(p => {
          const author = p.Author?.Title || "Unknown";
          contributorCounts[author] = (contributorCounts[author] || 0) + 1;
        });

        const top5Contributors = Object.entries(contributorCounts)
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5);
        console.log("Top 5 contributors:", top5Contributors);
        setTopContributors(top5Contributors);
        const top5LikedPrompts = [...approvedPrompts]
          .sort((a, b) => (b.LikesCount || 0) - (a.LikesCount || 0))
          .slice(0, 5)
          .map(p => ({
            id: p.Id,
            title: p.Title,
            likes: p.LikesCount || 0,
          }));
        console.log("Top 5 liked prompts:", top5LikedPrompts);
        setTopPrompts(top5LikedPrompts);
        const top5Newest = [...approvedPrompts]
          .sort((a, b) => new Date(b.Created) - new Date(a.Created))
          .slice(0, 5)
          .map(p => ({
            id: p.Id,
            title: p.Title,
            created: p.Created,
            likes:  p.LikesCount || 0,
          }));
        console.log("Top 5 newest prompts:", top5Newest);
        setNewPromptsList(top5Newest);

        if (activeToolbar === "likes") {
          filtered = filtered.filter((p) =>
            userLikedPrompts.includes(p.Id.toString())
          );
        }
        if (activeToolbar === "favourites") {
          filtered = filtered.filter((p) =>
            favoritePrompts.includes(p.Id.toString())
          );
        }
        const searchLower = searchText.toLowerCase();
        filtered = filtered.filter(
          (p) =>
            p.Title?.toLowerCase().includes(searchLower) ||
            p.Description?.toLowerCase().includes(searchLower) ||
            p.Prompt?.toLowerCase().includes(searchLower)
        );

        // Group for categories
        const groupedByCategory = filtered.reduce((acc, item) => {
          const cat = item.Category?.trim() || "Uncategorized";
          (acc[cat] ||= []).push(item);
          return acc;
        }, {});
        const groupedByCategories = filtered.reduce((acc, item) => {
          const cat = item.Categories?.trim() || "Uncategorized";
          (acc[cat] ||= []).push(item);
          return acc;
        }, {});
        // Group for departments
        const groupedByDept = filtered.reduce((acc, item) => {
          (item.Departments || "")
            .split(";")
            .map((d) => d.trim())
            .forEach((dep) => {
              if (dep) (acc[dep] ||= []).push(item);
            });
          return acc;
        }, {});

        setfetchPrompts(groupedByCategory);
        setgCategories(groupedByCategories);
        setgDeptPrompts(groupedByDept);
        console.log("Prompts grouped by Category:", groupedByCategory);
        console.log("Prompts grouped by Category:", groupedByCategories);
        // Update counts
        setPromptCategories((prev) =>
          prev.map((c) => ({
            ...c,
            prompts: groupedByCategory[c.title]?.length || 0,
          }))
        );
        console.log("promptCategories after count update:", promptCategories);
        setCategories((prev) =>
          prev.map((c) => ({
            ...c,
            prompts: groupedByCategories[c.title]?.length || 0,
          }))
        );
        console.log("pmtCategories after count update:", categories);
        setDepartments((prev) =>
          prev.map((d) => ({
            ...d,
            prompts: groupedByDept[d.title]?.length || 0,
          }))
        );
      } catch (e) {
        console.error("❌ Error:", e);
      }
    };

    fetchAll();
  }, [searchText, userCostCenters, activeToolbar, userLikedPrompts, favoritePrompts]);

  // -------------------------------------------------------
  // Toolbar Logic
  // -------------------------------------------------------
  let cardsToRender = promptCategories;
  let aPrompts = fetchPrompts;
  if (activeToolbar === "all") {
    cardsToRender = promptCategories.filter(cat =>
    (fetchPrompts[cat.title]?.length || 0) > 0
  );
    aPrompts = fetchPrompts;
  }
  else if (activeToolbar === "apps") {
    cardsToRender = promptCategories.filter(cat =>
    (fetchPrompts[cat.title]?.length || 0) > 0
  );
    aPrompts = fetchPrompts;
  }
  else if (activeToolbar === "categories") {
    cardsToRender = categories.filter(cat =>
    (gcategories[cat.title]?.length || 0) > 0
  );
    console.log("cardsToRender:", cardsToRender);
    aPrompts = gcategories;
  }
  else if (activeToolbar === "departments") {
    //cardsToRender = departments;
    cardsToRender = departments.filter(cat =>
    (gDeptPrompts[cat.title]?.length || 0) > 0
  );
    aPrompts = gDeptPrompts;
  }
  else if (activeToolbar === "favourites") {
    cardsToRender = promptCategories.filter(cat =>
    (fetchPrompts[cat.title]?.length || 0) > 0
  );
    aPrompts = fetchPrompts;
  }
  else if (activeToolbar === "likes") {
    cardsToRender = promptCategories.filter(cat =>
    (fetchPrompts[cat.title]?.length || 0) > 0
  );
    aPrompts = fetchPrompts;
  }
   else if (activeToolbar === "prompts") {
    // Only prompts created by user
    //cardsToRender = promptCategories;
    cardsToRender = promptCategories.filter(cat =>
    (fetchPrompts[cat.title]?.length || 0) > 0
  );
    aPrompts = Object.fromEntries(
      Object.entries(fetchPrompts).map(([cat, list]) => [
        cat,
        list.filter(
          (p) =>
            p.Author?.Title === props.context.pageContext.user.displayName
        ),
      ])
    );
  }
  const truncate = (text: string, max: number) => {
    if (!text) return "";
    return text.length > max ? text.substring(0, max) + "..." : text;
  };
  const openDetailView = (filter: { type: string; value: any }) => {
    setSelectedCategory(filter);
  };

  if (selectedCategory) {
    return (
      <PromptDetails
        context={props.context}
        category={selectedCategory}
        configItems={configItems}
        pcategories={pCategories}
        promptCategories={cardsToRender}
        categories={categories}
        prompts={aPrompts}
        departments={userDepartment}
        personas={[]}
        onBack={() => setSelectedCategory(null)}
      />
    );
  }

  // -------------------------------------------------------
  // MAIN UI
  // -------------------------------------------------------
  return (
    <div className={styles.root}>
      {/* PAGE TITLE */}
      <div className={styles.pageTitleWrapper}>
        <SparkleRegular className={styles.pageTitleIcon}  aria-label="Prompts" />
        <span className={styles.pageTitleText}>Prompt Buddy</span>
      </div>

      {/* ------- TOP SECTION -------- */}
      <div className={styles.container}>

        {/* TOP CONTRIBUTORS */}
        <div className={styles.section}>
          <div className={styles.header}>
            <PeopleCommunityRegular aria-label="Top Contributors" /> Top Contributors
          </div>

          {topContributors.map((c, i) => (
            <div 
              key={i} 
              className={styles.itemRow}
              style={{ cursor: "pointer" }}
              onClick={() => openDetailView({ type: "author", value: c.name })}
            >
              <div className={styles.left}>
                <Text>{i + 1}.</Text>

                <Avatar 
                  aria-label="Top Contributors"
                  name={c.name}
                  size={24}
                  color="neutral"
                  className={styles.contributorAvatar}
                />

                <Text className={styles.name}>
                  {truncate(c.name, 20)}
                </Text>
              </div>

              <Text className={styles.count}>{c.count} prompts</Text>
            </div>
          ))}
        </div>

        {/* TOP PROMPTS */}
        <div className={styles.section}>
          <div className={styles.header}>
            <LightbulbFilamentRegular aria-label="Top Prompts" /> Top Prompts
          </div>

          {topPrompts.map((p, i) => (
            <div 
              key={i} 
              className={styles.itemRow}
              style={{ cursor: "pointer" }}
              onClick={() =>
                openDetailView({
                  type: "promptId",
                  value: p.Id || p.id || p.ID
                })
              }

            >
              <div className={styles.left}>
                <Text>{i + 1}.</Text>

                <Avatar 
                  aria-label="Top Prompts"
                  icon={<LightbulbFilamentRegular  aria-label="Top Prompts" />}
                  size={24}
                  color="neutral"
                />

                <Text className={styles.title}>{truncate(p.title, 40)}</Text>
              </div>

              <div className={styles.count}>
                <HeartRegular  aria-label="likes" /> {p.likes || 0}
              </div>
            </div>
          ))}
        </div>

        {/* NEW PROMPTS */}
        <div className={styles.section}>
          <div className={styles.header}>
            <SparkleRegular aria-label="New Prompts" /> New Prompts
          </div>

          {newPromptsList.map((p, i) => (
            <div 
              key={i} 
              className={styles.itemRow}
              style={{ cursor: "pointer" }}
              onClick={() =>
                openDetailView({
                  type: "promptId",
                  value: p.Id || p.id || p.ID
                })
              }

            >
              <div className={styles.left}>
                <Text>{i + 1}.</Text>

                <Avatar 
                  aria-label="New Prompts"
                  icon={<SparkleRegular aria-label="New Prompts" />}
                  size={24}
                  color="neutral"
                />

                <Text className={styles.title}>{truncate(p.title, 40)}</Text>
              </div>

              <div className={styles.count}>
                <HeartRegular aria-label="likes" /> {p.likes || 0}
              </div>
            </div>
          ))}
        </div>

      </div>


      {/* --------- TOOLBAR --------- */}
      <div className={styles.toolbar}>
        {toolbarItems.map(({ key, label }) => (
          <div
            key={key}
            className={`${styles.toolbarItem} ${
              activeToolbar === key ? styles.active : ""
            }`}
            onClick={() => setActiveToolbar(key)}
          >
            <span style={{ fontWeight: 600 }}>{label}</span>
          </div>
        ))}
      </div>

      {/* ---------- SEARCH BAR ---------- */}
      <div className={styles.searchBar}>
        <Input
          aria-label="Search Prompts"
          contentBefore={<SearchRegular aria-label="Search" />}
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}          
          placeholder="Search prompt titles and descriptions"
          appearance="outline"
          className={styles.searchInput}
        />
      </div>

      {/* ---------- CATEGORY / DEPT CARDS ---------- */}
      <div className={styles.cardGrid}>
        {cardsToRender.map((c, i) => (
          <div key={i} className={styles.cardWrapper}>
            <Card
              className={styles.card}
              style={{ background: c.gradient }}
              onClick={() => setSelectedCategory(c)}
            >
              <div className={styles.cardOverlay}></div>

              <div className={styles.cardInner}>
                <div className={styles.cardIcon}>{c.icon}</div>
                <Text weight="semibold" className={styles.cardTitle}>
                  {c.title}
                </Text>
                <Text className={styles.cardDesc}>{c.description}</Text>
              </div>
            </Card>

            <Text className={styles.cardCount}>{c.prompts} prompts</Text>
          </div>
        ))}
      </div>
    </div>
  );
}
