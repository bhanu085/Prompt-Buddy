// @ts-nocheck
import * as React from "react";
import styles from "./PromptDetails.module.scss";
import PromptSidebar from "./PromptSidebar";
import {
  Button,
  Menu,
  MenuTrigger,
  MenuList,
  MenuItem,
  Dialog,
  DialogSurface,
  DialogBody,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogTrigger,
  Dropdown,
  Option,
  Combobox,
} from "@fluentui/react-components";

import {
  ArrowLeftRegular,
  ThumbLikeRegular,
  ThumbLikeFilled,
  ShareRegular,
  MoreHorizontalRegular,
  CopyRegular,
  DeleteRegular,
  AttachRegular,
  ArrowUploadRegular,
  TagRegular,
  SparkleRegular,
  ExpandUpRightRegular,
  DismissRegular
} from "@fluentui/react-icons";
import { DismissRegular } from "@fluentui/react-icons";
import { spfi, SPFx } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/fields";
import "@pnp/sp/site-users/web";
import { graphfi } from "@pnp/graph";
import { GraphSPFx } from "@pnp/graph";
import "@pnp/sp/profiles";
import "@pnp/graph/teams";
import { Dropdown, Option } from "@fluentui/react-components";
import { Radio, RadioGroup } from "@fluentui/react-components";
import { PeoplePicker, PrincipalType} from "@pnp/spfx-controls-react/lib/PeoplePicker";


export default function PromptDetails({ context, category,configItems, pcategories, promptCategories, categories, prompts, departments,
  personas, onBack }) {
console.log("pCategories:", pcategories);
console.log("promptCategories:", promptCategories);
console.log("prompts keys:", Object.keys(prompts));
console.log("Categories:", categories);
console.log("Category prop:", category);
const [canShowSubmit, setCanShowSubmit] = React.useState(false);
//const [showTips, setShowTips] = React.useState(false);
//   let filteredCategories = promptCategories;   
//   let filteredPromptsByCategory = prompts; 
//   if (category?.type === "author") {
//     const promptsByAuthor = {};
//     Object.keys(prompts).forEach(cat => {
//       const items = prompts[cat].filter(p =>
//           p.Author?.Title === category.value &&
//           (p.Status === "Approved" || p.status === "Approved")
//       );

//       if (items.length > 0) {
//         promptsByAuthor[cat] = items;
//       }
//     });
//     filteredPromptsByCategory = promptsByAuthor;
//     let fCategories = Object.keys(promptsByAuthor);
//     console.log("Filtered prompts by author:", fCategories);
//     filteredCategories = promptCategories
//       .filter(c => fCategories.includes(c.title))
//       .map(c => {
//         const count = prompts[c.title].filter(
//           p =>
//             p.Author?.Title === category.value &&
//             (p.Status === "Approved" || p.status === "Approved")
//         ).length;

//         return {
//           ...c,
//           prompts: count 
//         };
//       });

//     console.log("Filtered prompts by author:", filteredCategories);
//   }
//   if (category?.type === "promptId") {
//     let matchedCategory = null;
//     let matchedPrompt = null;
//     Object.keys(prompts).forEach(cat => {
//       const found = prompts[cat].find(
//         p => (p.Id || p.id || p.ID)?.toString() === category.value?.toString()
//       );
//       if (found) {
//         matchedCategory = cat;
//         matchedPrompt = found;
//       }
//     });
//     if (matchedCategory && matchedPrompt) {
//       filteredCategories = promptCategories
//         .filter(c => c.title === matchedCategory)
//         .map(c => ({
//           ...c,
//           prompts: 1
//         }));
//       filteredPromptsByCategory = {
//         [matchedCategory]: [matchedPrompt]
//       };
//       selectedCategory = filteredCategories[0];
//     }
//   }
//   const allCount = Object.values(filteredPromptsByCategory).flat().length;
//   filteredCategories = [
//   {
//     title: "All",
//     prompts: allCount,
//     icon: <SparkleRegular />,
//     gradient: "linear-gradient(135deg, #6C63FF 0%, #8B82FF 50%, #B8B4FF 100%)",
//     description: "View all prompts"
//   },
//   ...filteredCategories
// ];
const {
  filteredCategories,
  filteredPromptsByCategory,
  resolvedSelectedCategory
} = React.useMemo(() => {

  let cats = [...promptCategories];
  let pr = { ...prompts };
  let sel = null;

  // -------- AUTHOR FILTER --------
  if (category?.type === "author") {
    const byAuthor: any = {};

    Object.keys(prompts).forEach(cat => {
      const items = prompts[cat].filter(
        p =>
          p.Author?.Title === category.value &&
          (p.Status === "Approved" || p.status === "Approved")
      );
      if (items.length) byAuthor[cat] = items;
    });

    cats = cats
      .filter(c => byAuthor[c.title])
      .map(c => ({
        ...c,
        prompts: byAuthor[c.title].length
      }));

    pr = byAuthor;
  }

  // -------- PROMPT ID FILTER --------
  if (category?.type === "promptId") {
    let matchedCat = null;
    let matchedPrompt = null;

    Object.keys(prompts).forEach(cat => {
      const found = prompts[cat].find(
        p => (p.Id || p.id || p.ID)?.toString() === category.value?.toString()
      );
      if (found) {
        matchedCat = cat;
        matchedPrompt = found;
      }
    });

    if (matchedCat && matchedPrompt) {
      cats = cats
        .filter(c => c.title === matchedCat)
        .map(c => ({ ...c, prompts: 1 }));

      pr = { [matchedCat]: [matchedPrompt] };
      sel = cats[0];
    }
  }

  // -------- ADD "ALL" ONCE --------
  const allCount = Object.values(pr).flat().length;

  cats = [
    {
      title: "All",
      prompts: allCount,
      icon: <SparkleRegular aria-label="Sparkle" />,
      gradient:
        "linear-gradient(135deg, #6C63FF 0%, #8B82FF 50%, #B8B4FF 100%)",
      description: "View all prompts"
    },
    ...cats
  ];

  return {
    filteredCategories: cats,
    filteredPromptsByCategory: pr,
    resolvedSelectedCategory: sel
  };
}, [category, promptCategories, prompts]);

  console.log("Using filteredCategories in PromptDetails:", filteredCategories);
  const [days, setDays] = React.useState("");
  const [hours, setHours] = React.useState("");
  const [minutes, setMinutes] = React.useState("");

  const [promptList, setPromptList] = React.useState(filteredPromptsByCategory);
  const [userLikedPrompts, setUserLikedPrompts] = React.useState<string[]>([]);
  const [favState, setFavState] = React.useState({});
  const [openMenuId, setOpenMenuId] = React.useState(null);  
  const [selectedPrompt, setSelectedPrompt] = React.useState<any | null>(null);
  const [expandedTipsId, setExpandedTipsId] = React.useState<number | null>(null);
  const [copyState, setCopyState] = React.useState({});
  const categoryTitles = React.useMemo(() => {
    return [
      "Select a Category",
      ...(categories || []).map(cat => cat.title)
    ];
  }, [categories]);
  const categoryTitle = React.useMemo(() => {
    return [
      "Category",
      ...(categories || []).map(cat => cat.title)
    ];
  }, [categories]);

  const getSP = (context?: any) => {
    try {
      if (context) {
        console.log("Using SPFx context for PnP");
        return spfi().using(SPFx(context));
      } else {
        console.log("Using manual base URL fallback");
        return spfi("https://test.sharepoint.com");
      }
    } catch (err) {
      console.error("Error initializing PnP:", err);
      return spfi("https://test.sharepoint.com");
    }
  };
  const deptOptions = Array.isArray(departments)
  ? departments
  : departments
  ? [ { title: departments } ]
  : [];

const defaultCat =
  filteredCategories.length > 0
    ? filteredCategories[0]
    : { title: "Copilot (M365)" };


  const [selectedCategory, setSelectedCategory] = React.useState(
    resolvedSelectedCategory || defaultCat
  );

  React.useEffect(() => {
    if (resolvedSelectedCategory) {
      setSelectedCategory(resolvedSelectedCategory);
    }
  }, [resolvedSelectedCategory]);

  React.useEffect(() => {
    setFormData(prev => ({
      ...prev,
      app: category?.title || defaultCat.title || ""
    }));
  }, [category]);
  React.useEffect(() => {
    let cancelled = false;
    const sp = getSP(context);
    const checkMembership = async () => {
      try {
        const myGroups = await sp.web.currentUser.groups.select("Title")();
        console.log("SubmitPromptAction group name from config:", configItems?.SubmitPromptAction);
        console.log("Current user's groups:", myGroups);
        const allowed = myGroups.some(
          (g) =>
            (g?.Title ?? "").trim().toLowerCase() === configItems?.SubmitPromptAction.toLowerCase()
        );

        if (!cancelled) setCanShowSubmit(allowed);
      } catch (e) {
        console.error("Error checking SubmitPromptAction group membership:", e);
        if (!cancelled) setCanShowSubmit(false);
      }
    };

    checkMembership();   
  }, []);
  const [formData, setFormData] = React.useState({
  app: category?.title || defaultCat.title || "",
  title: "",
  category:"",
  desc: "",
  prompt: "",
  tags: "",
  departments: "",
  imageFile: null,
  attachFiles: [],
  tips:"",
  roi:"",
  ets:""
  });
  //const isDeptDisabled = formData.promptVisibility !== "Department";
  const resetForm = () => {
  setFormData({
    app: "",
    title: "",
    category:"",
    desc: "",
    prompt: "",
    tags: "",
    departments: "",
    imageFile: null,
    attachFiles: [],
    tips:"",
    roi:"",
    ets:""
  });

  const fileInput = document.getElementById("fileUpload") as HTMLInputElement;
  const imageInput = document.getElementById("imageUpload") as HTMLInputElement;
  if (fileInput) fileInput.value = "";
  if (imageInput) imageInput.value = "";
  };

  const normalize = (str: string) =>
    str
      ?.toString()
      .toLowerCase()
      .normalize("NFKD")
      .replace(/\s+/g, "")
      .replace(/[()]/g, "")
      .replace(/[^a-z0-9]/g, "")
      .trim() || "";

  const isObject = (v: any) => v && typeof v === "object" && !Array.isArray(v);

  const data = isObject(promptList) ? promptList : {};
  const allKeys = Object.keys(data); 
 
      
  const [isShareOpen, setShareOpen] = React.useState(false);
  const [sharePrompt, setSharePrompt] = React.useState(null);

  
  const [showSubmitForm, setShowSubmitForm] = React.useState(false);
  const [previewImage, setPreviewImage] = React.useState(null);
  React.useEffect(() => {
    if (category && category.title) setSelectedCategory(category);
  }, [category?.title]);
  React.useEffect(() => {
  const fetchUserSummary = async () => {
    try {
      const sp = getSP(context);
      const currentUser = context.pageContext.user.email || context.pageContext.user.loginName;
      const list = sp.web.lists.getByTitle("UserPromptSummary");
      const items = await list.items.filter(`Title eq '${currentUser}'`).top(1)();

      if (items.length > 0) {
        const likedIds = (items[0].PromptsLiked || "")
          .split(/[;,]/)
          .map((x) => x.trim())
          .filter(Boolean);
        const favIds = (items[0].FavoritePrompts || "")
          .split(/[;,]/)
          .map((x) => x.trim())
          .filter(Boolean);

        setUserLikedPrompts(likedIds);
        setFavState(Object.fromEntries(favIds.map((id) => [id, true])));
        console.log("Favorites loaded:", favIds);
      } else {
        setUserLikedPrompts([]);
        setFavState({});
      }
    } catch (err) {
      console.error("Error fetching user summary:", err);
    }
  };

  if (context?.pageContext?.user) fetchUserSummary();
  }, [context]);

// React.useEffect(() => {
//   const fetchUserLikes = async () => {
//     try {
//       const sp = getSP(context);
//       const currentUser = context.pageContext.user.email || context.pageContext.user.loginName;
//       const list = sp.web.lists.getByTitle("UserPromptSummary");

//       const items = await list.items.filter(`Title eq '${currentUser}'`).top(1)();

//       if (items.length > 0 && items[0].PromptsLiked) {
//         const likedIds = items[0].PromptsLiked.split(/[;,]/)
//           .map((x: string) => x.trim())
//           .filter(Boolean);
//         setUserLikedPrompts(likedIds);
//         console.log("Liked prompt IDs for current user:", likedIds);
//       } else {
//         setUserLikedPrompts([]);
//       }
//     } catch (err) {
//       console.error("Error fetching user likes:", err);
//     }
//   };

//   if (context?.pageContext?.user) fetchUserLikes();
// }, [context]);
  const matchedKey = React.useMemo(() => {
  const wanted = normalize(selectedCategory?.title);
  const hit = allKeys.find((k) => normalize(k) === wanted);
  return hit || null;
  }, [selectedCategory?.title, allKeys]); 
  const promptsData = React.useMemo(() => {
    if (selectedCategory?.title === "All") {
      return Object.values(filteredPromptsByCategory).flat();
    }
    const list =
      matchedKey && filteredPromptsByCategory[matchedKey]
        ? filteredPromptsByCategory[matchedKey]
        : [];

    return Array.isArray(list) ? list : [];
  }, [
    selectedCategory?.title,
    matchedKey,
    filteredPromptsByCategory
  ]);
  React.useEffect(() => {
  if (!Array.isArray(promptsData)) return;

  const next = {};

  promptsData.forEach((p) => {
    const itemId = p?.Id || p?.id || p?.ID;
    if (!itemId) return;

    next[itemId] = Number(p?.CopyCount || 0);
  });

  setCopyState(next);
}, [promptsData]);


  const handleCategorySelect = (cat) => setSelectedCategory(cat);
  const goBack = typeof onBack === "function" ? onBack : () => {};

  const [likesState, setLikesState] = React.useState({});

  const makeId = React.useCallback(
    (i, title) =>
      `${matchedKey}-${i}-${(title || "").toLowerCase().replace(/\s+/g, "-")}`,
    [matchedKey]
   );
  const [channels, setChannels] = React.useState([]);
  const [selectedChannels, setSelectedChannels] = React.useState<string[]>([]);

// when user chooses a team
  const handleTeamSelect = async (teamId: string) => {
  const graphClient = await context.msGraphClientFactory.getClient();
  const res = await graphClient.api(`/teams/${teamId}/channels`).get();
  setChannels(res.value || []);
  };
//   React.useEffect(() => {
//   setLikesState(() => {
//     const next = {};
//     promptsData.forEach((p, i) => {
//       const itemId = p?.Id || p?.id || p?.ID;
//       const isLiked = userLikedPrompts.includes(itemId?.toString());
//       next[makeId(i, p?.Title)] = {
//         liked: isLiked,
//         count: Number(p?.LikesCount || p?.likes) || 0,
//       };
//     });
//     return next;
//   });
// }, [promptsData, userLikedPrompts, makeId]);
React.useEffect(() => {
  // do not run if promptsData is undefined/null
  if (!Array.isArray(promptsData)) return;

  const next = {};

  promptsData.forEach((p, i) => {
    const itemId = p?.Id || p?.id || p?.ID;
    if (!itemId) return;

    // stable unique key — DOES NOT depend on matchedKey or title
    const key = `${itemId}`;

    const isLiked = userLikedPrompts.includes(itemId.toString());

    next[key] = {
      liked: isLiked,
      count: Number(p?.LikesCount || p?.likes) || 0
    };
  });

  requestAnimationFrame(() => {
  setLikesState(next);
});

}, [promptsData, userLikedPrompts]);


React.useEffect(() => {
  const firstTitle = promptCategories?.[0]?.title;
  if (!firstTitle) return;

  setFormData((prev) => {
    if (prev.app === firstTitle && prev.tags === firstTitle) return prev;
    return { ...prev, app: prev.app || firstTitle, tags: prev.tags || firstTitle };
  });
}, [promptCategories?.[0]?.title]);
// Initialize default department (only once when list loads)
// React.useEffect(() => {
//   const firstDept = departments?.[0]?.title;
//   if (!firstDept) return;

//   setFormData(prev => {
//     if (prev.departments) return prev; // don’t overwrite if user already selected
//     return { ...prev, departments: firstDept };
//   });
// }, [departments]);

// // Initialize default persona (only once when list loads)
// React.useEffect(() => {
//   const firstPersona = personas?.[0]?.title;
//   if (!firstPersona) return;

//   setFormData(prev => {
//     if (prev.personas) return prev;
//     return { ...prev, personas: firstPersona };
//   });
// }, [personas]);


const [joinedTeams, setJoinedTeams] = React.useState([]);

React.useEffect(() => {
  const fetchTeams = async () => {
    try {
      const graphClient = await context.msGraphClientFactory.getClient();
      const res = await graphClient.api("/me/joinedTeams").get();
      console.log("Joined Teams:", res.value);

      setJoinedTeams(
        (res.value || []).map((t: any) => ({
          id: t.id,
          displayName: t.displayName,
        }))
      );
    } catch (err) {
      console.error("Error fetching joined teams:", err);
    }
  };

  if (context) fetchTeams();
}, [context]);


const handleSubmitPrompt = async () => {
  let errors: string[] = [];

  if (!formData.title?.trim()) errors.push("Title is required.");
  if (!formData.desc?.trim()) errors.push("Description is required.");
  if (!formData.prompt?.trim()) errors.push("Prompt text is required.");
  if (!formData.category?.trim()) errors.push("Category is required.");
  if (formData.promptVisibility === "Department") {
    if (!formData.departments?.trim()) {
      errors.push("Please select at least one department.");
    }
  }

  if (errors.length > 0) {
    alert("Please fix the following issues:\n\n" + errors.join("\n"));
    return; 
  }
  const sp = getSP(context);
  if (!sp) {
    alert("SharePoint context not initialized");
    return;
  }

  try {
    console.log("Submitting prompt...");
    const d = days ? Number(days) : 0;
    const h = hours ? Number(hours) : 0;
    const m = minutes ? Number(minutes) : 0;
    formData.ets = `${d}d ${h}h ${m}m`;

    // formData.ets = `${days}d ${hours}h ${minutes}m`;
    const itemAddResult = await sp.web.lists
      .getByTitle("Prompts")
      .items.add({
        Title: formData.title || "Untitled Prompt",
        Description: formData.desc || "",
        Prompt: formData.prompt || "",
        Departments: formData.departments || "All",
        Status: "In Review",
        Category: formData.app || "",
        Categories: formData.category || "",
        TIPS: formData.tips || "",
        ROI: formData.roi || "",
        ETS: formData.ets || "",
        LikesCount: 0,
        SharingCount: 0,
        CopyCount: 0,
        TeamsShared: "", 
      });
    console.log("List item created:", itemAddResult);
    const itemId = itemAddResult.Id;
    console.log("Created list item:", itemId);
    if (formData.attachFiles?.length > 0) {
      for (const file of formData.attachFiles) {
        const arrayBuffer = await file.arrayBuffer();
        await sp.web.lists
          .getByTitle("Prompts")
          .items.getById(itemId)
          .attachmentFiles.add(file.name, arrayBuffer);
      }
      console.log("Attachments uploaded successfully");
    }
    if (formData.imageFile) {
      const arrayBuffer = await formData.imageFile.arrayBuffer();
        const uploadResult = await sp.web.lists
          .getByTitle("Prompts")
          .items.getById(itemId)
          .attachmentFiles.add(formData.imageFile.name, arrayBuffer);
      }
      console.log("Upload Result:", uploadResult);
      const absoluteUrl = uploadResult?.data?.ServerRelativeUrl;
      await sp.web.lists
      .getByTitle("Prompts")
      .items.getById(itemId)
      .update({
        ImageUrl: absoluteUrl, 
    });     
    console.log("Image uploaded to PromptIcon column");    
    alert("Prompt submitted successfully!");
    window.location.reload();
  } catch (err) {
    console.error("Error submitting prompt:", err);
    alert("Error while submitting prompt. See console for details.");
  }
};
const updateLikeInSharePoint = async (itemId, newCount) => {
  try {
    const sp = getSP(context);
    await sp.web.lists
      .getByTitle("Prompts")
      .items.getById(itemId)
      .update({ LikesCount: newCount });
    console.log(`Updated LikesCount to ${newCount} for item ${itemId}`);
  } catch (err) {
    console.error("Failed to update LikesCount:", err);
  }
};
// const updateUserPromptSummaryOnLike = async (loginName, promptId) => {
//   try {
//     const sp = getSP(context);
//     const list = sp.web.lists.getByTitle("UserPromptSummary");

//     // Check if user already exists
//     const existingItems = await list.items
//       .filter(`Title eq '${loginName}'`)
//       .top(1)();

//     if (existingItems.length > 0) {
//       const item = existingItems[0];
//       const liked = item.PromptsLiked ? item.PromptsLiked.split(/[;,]/).map(s => s.trim()) : [];

//       // Append only if not already there
//       if (!liked.includes(promptId.toString())) {
//         liked.push(promptId.toString());
//         await list.items.getById(item.Id).update({
//           PromptsLiked: liked.join(";"),
//         });
//         console.log(`Updated likes for ${loginName}:`, liked.join(";"));
//       }
//     } else {
//       // Add new row
//       await list.items.add({
//         Title: loginName,
//         PromptsLiked: promptId.toString(),
//         PromptsShared: "",
//         TeamsUserIsMemberOf: "",
//       });
//       console.log(`Added new user summary for ${loginName}`);
//     }
//   } catch (err) {
//     console.error("Error updating UserPromptSummary (Like):", err);
//   }
// };
const updateUserPromptSummaryOnLike = async (loginName, promptId, isLiked) => {
  try {
    const sp = getSP(context);
    const list = sp.web.lists.getByTitle("UserPromptSummary");
    const existingItems = await list.items.filter(`Title eq '${loginName}'`).top(1)();

    if (existingItems.length > 0) {
      const item = existingItems[0];
      const liked = item.PromptsLiked
        ? item.PromptsLiked.split(/[;,]/).map(s => s.trim()).filter(Boolean)
        : [];

      if (isLiked) {
        if (!liked.includes(promptId.toString())) liked.push(promptId.toString());
      } else {
        const index = liked.indexOf(promptId.toString());
        if (index > -1) liked.splice(index, 1);
      }

      await list.items.getById(item.Id).update({
        PromptsLiked: liked.join(";"),
      });
      console.log(`Updated likes for ${loginName}: ${liked.join(";")}`);
    } else if (isLiked) {
      await list.items.add({
        Title: loginName,
        PromptsLiked: promptId.toString(),
        PromptsShared: "",
        TeamsUserIsMemberOf: "",
      });
      console.log(`Added new user summary for ${loginName}`);
    }
  } catch (err) {
    console.error("Error updating UserPromptSummary (Like):", err);
  }
};

const updateUserPromptSummaryOnShare = async (loginName, promptId, sharedTeams = "") => {
  try {
    const sp = getSP(context);
    const list = sp.web.lists.getByTitle("UserPromptSummary");

    const existingItems = await list.items
      .filter(`User eq '${loginName}'`)
      .top(1)();

    if (existingItems.length > 0) {
      const item = existingItems[0];
      const shared = item.PromptsShared ? item.PromptsShared.split(/[;,]/).map(s => s.trim()) : [];

      if (!shared.includes(promptId.toString())) {
        shared.push(promptId.toString());
      }
      let teams = item.TeamsUserIsMemberOf || "";
      if (sharedTeams && !teams.includes(sharedTeams)) {
        teams = [teams, sharedTeams].filter(Boolean).join(";");
      }

      await list.items.getById(item.Id).update({
        PromptsShared: shared.join(";"),
        TeamsUserIsMemberOf: teams,
      });
      console.log(`Updated shared prompts for ${loginName}`);
    } else {
      await list.items.add({
        User: loginName,
        PromptsLiked: "",
        PromptsShared: promptId.toString(),
        TeamsUserIsMemberOf: sharedTeams || "",
      });
      console.log(`Added user summary on share for ${loginName}`);
    }
  } catch (err) {
    console.error("Error updating UserPromptSummary (Share):", err);
  }
};
const updateUserPromptSummaryOnFavorite = async (loginName, promptId, isFav) => {
  try {
    const sp = getSP(context);
    const list = sp.web.lists.getByTitle("UserPromptSummary");
    const existingItems = await list.items.filter(`Title eq '${loginName}'`).top(1)();

    if (existingItems.length > 0) {
      const item = existingItems[0];
      const favs = item.FavoritePrompts
        ? item.FavoritePrompts.split(/[;,]/).map((s) => s.trim()).filter(Boolean)
        : [];

      if (isFav) {
        if (!favs.includes(promptId.toString())) favs.push(promptId.toString());
      } else {
        const idx = favs.indexOf(promptId.toString());
        if (idx > -1) favs.splice(idx, 1);
      }

      await list.items.getById(item.Id).update({
        FavoritePrompts: favs.join(";"),
      });
      console.log(`Updated favorites for ${loginName}: ${favs.join(";")}`);
    } else if (isFav) {
      await list.items.add({
        Title: loginName,
        FavoritePrompts: promptId.toString(),
        PromptsLiked: "",
        PromptsShared: "",
        TeamsUserIsMemberOf: "",
      });
      console.log(`Added new user summary for ${loginName} (Favorites)`);
    }
  } catch (err) {
    console.error("Error updating UserPromptSummary (Favorites):", err);
  }
};
// const getLogsListName = async (sp) => {
//   try {
//     const configList = await sp.web.lists.getByTitle("Config");
//     const items = await configList.items
//       .filter("Title eq 'LogsListName'")
//       .top(1)();
//     console.log("Config items for LogsListName:", items);
//     if (items.length === 0) throw new Error("LogsListName not found in Config");
//     return items[0].Value;
//   } catch (err) {
//     console.error("Error reading Config list:", err);
//     throw err;
//   }
// };
const ensureUserActivityLogList = async (sp, listName) => {
  try {
    const lists = await sp.web.lists.select("Title")();
    const exists = lists.some((l) => l.Title === listName);

    if (!exists) {
      console.log(`Creating log list: ${listName}`);
      await sp.web.lists.add(listName, "Stores user prompt activity", 100);
      const list = await sp.web.lists.getByTitle(listName);
      await list.fields.addText("Title");
      await list.fields.addNumber("PromptID");
      await list.fields.addText("Action");
      await list.fields.addText("User");
      await list.fields.addDateTime("Timestamp");
      console.log(`Created list '${listName}' with required columns`);
    } else {
      console.log(`List '${listName}' already exists`);
    }
  } catch (err) {
    console.error("Error ensuring activity log list:", err);
  }
};
const addOrUpdateUserActivityLog = async (sp, listName, user, promptId, action) => {
  try {
    const list = await sp.web.lists.getByTitle(listName);
    const existing = await list.items
      .filter(`User eq '${user}' and PromptID eq ${promptId} and Action eq '${action}'`)
      .top(1)();
    const timestamp = new Date().toISOString();
    if (existing.length > 0) {
      const itemId = existing[0].Id;
      await list.items.getById(itemId).update({
        Timestamp: timestamp,
      });
      console.log(`Updated log for ${user}, prompt ${promptId}, action ${action}`);
    } else {
      await list.items.add({
        User: user,
        PromptID: promptId,
        Action: action,
        Timestamp: timestamp,
      });
      console.log(`Added new log for ${user}, prompt ${promptId}, action ${action}`);
    }
  } catch (err) {
    console.error("Error in addOrUpdateUserActivityLog:", err);
  }
};
const [selectedTeam, setSelectedTeam] = React.useState<string | null>(null);
const handleSharePrompt = async (promptId: number) => {
  try {
    const sp = getSP(context);
    const teamChannelList = selectedChannels.map(
      (ch) => `${ch}`
    );
    const sharedText = teamChannelList.join("; ");
    const shareCount = teamChannelList.length;
    await sp.web.lists
      .getByTitle("Prompts")
      .items.getById(promptId)
      .update({
        TeamsShared: sharedText,
        SharingCount: shareCount,
      });
      const currentUser = context.pageContext.user.email || context.pageContext.user.loginName;
      await updateUserPromptSummaryOnShare(currentUser, promptId, selectedChannels.join(";"));
      const logListName = configItems?.LogsListName || "UserActivityLog";
      console.log("Log List Name:", logListName);
      await ensureUserActivityLogList(sp, logListName);
      await addOrUpdateUserActivityLog(sp, logListName, currentUser, promptId, "Share");
      console.log("Prompt shared successfully:", { sharedText, shareCount });
      setShareOpen(false);    
      refreshPromptsData();
  } catch (err) {
    console.error("Error updating Prompts list:", err);
    alert("Error while sharing prompt. Check console for details.");
  }
};
const handleCopyItem = async (prompt) => {
  try {
    const sp = getSP(context);
    const promptId = prompt?.Id || prompt?.id || prompt?.ID;
    const title = prompt?.Title || "";
    const desc = prompt?.Description || "";
    const text = prompt?.Prompt || "";
    const currentUser = context.pageContext.user.email || context.pageContext.user.loginName;
    const textToCopy = `${text}`;
    try {
      await navigator.clipboard.writeText(textToCopy);
      console.log("Copied using Clipboard API");
    } catch (clipErr) {
      console.warn("Clipboard API failed, falling back:", clipErr);
      const textarea = document.createElement("textarea");
      textarea.value = textToCopy;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      console.log("Copied using execCommand fallback");
    }
    setCopyState(prev => ({
      ...prev,
      [promptId]: (prev[promptId] || 0) + 1
    }));
    const item = await sp.web.lists.getByTitle("Prompts").items.getById(promptId)();
    const currentCount = Number(item.CopyCount) || 0;
    await sp.web.lists
      .getByTitle("Prompts")
      .items.getById(promptId)
      .update({ CopyCount: currentCount + 1 });
    console.log(`CopyCount updated to ${currentCount + 1} for item ${promptId}`);
    const logListName = configItems?.LogsListName || "UserActivityLog";
    await ensureUserActivityLogList(sp, logListName);
    await addOrUpdateUserActivityLog(sp, logListName, currentUser, promptId, "Copy");

  } catch (err) {
    console.error("Error copying item:", err);
    alert("Error while copying prompt. See console for details.");
  }
};
const refreshPromptsData = async () => {
  try {
    const sp = getSP(context);
    const items = await sp.web.lists
        .getByTitle("Prompts")
        .items.select(
          "Id",
          "Title",
          "Description",
          "Prompt",
          "Tags",
          "Departments",
          "Status",
          "Category",
          "Categories",
          "LikesCount",
          "SharingCount",
          "CopyCount",
          "TeamsShared",
          "TIPS",
          "ROI",
          "ETS",
          "ImageUrl",
          "Created",
          "Modified",
          "Author/Title",
          "Editor/Title",
          "Attachments",
          "AttachmentFiles"
        )
        .expand("Author", "Editor", "AttachmentFiles")
        .top(500)();

      console.log("Fetched prompts:", items);

      const mapped = items.map((item) => ({
        id: item.Id,
        title: item.Title,
        description: item.Description,
        prompt: item.Prompt,
        tags: item.Tags,
        departments: item.Departments,
        status: item.Status,
        category: item.Category,
        categories: item.Categories,
        likes: item.LikesCount,
        sharing: item.SharingCount,
        copies: item.CopyCount,
        teamsShared: item.TeamsShared,
        tips: item.TIPS,
        roi: item.ROI,
        ets: item.ETS,
        imageUrl: item.ImageUrl || "",
        created: item.Created,
        modified: item.Modified,
        createdBy: item.Author?.Title,
        modifiedBy: item.Editor?.Title,
        attachments: item.AttachmentFiles?.map((f) => ({
          name: f.FileName,
          url: f.ServerRelativeUrl,
        })) || [],
      }));
      const grouped = mapped.reduce((acc, item) => {
        const category = item.category?.trim() || "Uncategorized";

        if (!acc[category]) {
          acc[category] = [];
        }

        acc[category].push({
          id: item.id,
          title: item.title,
          author: item.createdBy || "Unknown",
          status: item.status || "Pending",
          likes: item.likes || 0,
          sharing: item.sharing || 0,
          date: new Date(item.created).toLocaleString("en-US", {
            month: "2-digit",
            day: "2-digit",
            year: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            hour12: true,
          }),
          desc: item.description || "",
        });

        return acc;
      }, {});
    setPromptList(grouped);
    console.log("Prompts refreshed:", promptList);
  } catch (err) {
    console.error("Error refreshing prompts:", err);
  }
};
const getCopyCount = (p: any) => {
  const id = p?.Id || p?.id || p?.ID;
  return copyState[id] ?? Number(p?.CopyCount) ?? 0;
};

const getLikeCount = (p: any) => {
  const id = (p?.Id || p?.id || p?.ID)?.toString();
  return likesState[id]?.count ?? Number(p?.LikesCount) ?? 0;
};
const filteredAndSortedPrompts = React.useMemo(() => {
  let list = [...promptsData];  
  if (formData.category && formData.category !== "Category") {
    list = list.filter(
      p =>
        (p?.categories || p?.Categories || "")
          .trim()
          .toLowerCase() === formData.category.toLowerCase()
    );
  }
  switch (formData.sortBy) {
    case "newest":
      list.sort(
        (a, b) =>
          new Date(b?.Created || b?.date || 0).getTime() -
          new Date(a?.Created || a?.date || 0).getTime()
      );
      break;

    case "liked":
      list.sort((a, b) => getLikeCount(b) - getLikeCount(a));
      break;

    case "copied":
      list.sort((a, b) => getCopyCount(b) - getCopyCount(a));
      break;

    case "ets":
      // Converts "2d 3h 15m" → total minutes
      const toMinutes = (ets = "") => {
        const d = /(\d+)d/.exec(ets)?.[1] || 0;
        const h = /(\d+)h/.exec(ets)?.[1] || 0;
        const m = /(\d+)m/.exec(ets)?.[1] || 0;
        return Number(d) * 1440 + Number(h) * 60 + Number(m);
      };

      list.sort(
        (a, b) =>
          toMinutes(b?.ETS || b?.ets) -
          toMinutes(a?.ETS || a?.ets)
      );
      break;

    case "roi":
      // $$$ > $$ > $
      const roiRank = (r = "") =>
        r === "$$$" ? 3 : r === "$$" ? 2 : r === "$" ? 1 : 0;

      list.sort(
        (a, b) =>
          roiRank(b?.ROI || b?.roi) -
          roiRank(a?.ROI || a?.roi)
      );
      break;

    default:
      break;
  }

  return list;
}, [promptsData, formData.category, formData.sortBy]);

React.useEffect(() => {
  console.log("promptList state updated:", promptList);
}, [promptList]);
  return (
    <div className={styles.wrapper}>
      <PromptSidebar
        promptCategories={filteredCategories}
        ShowSubmitButton={canShowSubmit}
        selectedCategory={selectedCategory}
        onSelectCategory={handleCategorySelect}
        onSubmitPrompt={() => setShowSubmitForm(true)}
        showSubmitForm={showSubmitForm}
      />
      {!showSubmitForm ? (
      <div className={styles.content}>
        <div className={styles.header}>
          <Button icon={<ArrowLeftRegular aria-label="Back" />} appearance="subtle" onClick={goBack}>
            Back
          </Button>

          <div className={styles.categoryTitleBlock}>
            <div className={styles.categoryTitle}>
              {selectedCategory?.title || matchedKey || "Category"}
            </div>
            <div className={styles.categorySubtitle}>
              Prompts for {selectedCategory?.title || matchedKey || "—"}
            </div>
          </div>
          <div className={styles.headerRight}>
            <select className={styles.fieldDropdown} value={formData.category || "Category"}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  category:
                    e.target.value === "Category" ? "" : e.target.value
                })
              }
            >
              {categoryTitle.map((title, index) => (
                <option key={index} value={title}>
                  {title}
                </option>
              ))}
            </select>
            <select
              className={styles.fieldDropdown}
              value={formData.sortBy || "Sort By"}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  sortBy: e.target.value === "Sort By" ? "" : e.target.value
                })
              }
            >
              <option value="Sort By">Sort By</option>
              <option value="newest">Newest</option>
              <option value="liked">Most Liked</option>
              <option value="copied">Most Copied</option>
              {/* <option value="ets">Estimated Time Saved</option>
              <option value="roi">ROI Impact Tier</option> */}
            </select>
          </div>
        </div>

        <div className={styles.promptList}>
          {promptsData.length === 0 ? (
            <div className={styles.emptyState}>
              <div className={styles.emptyIcon} aria-hidden>
                
              </div>
              <div>No prompts found for this category.</div>
            </div>
          ) : (
            console.log("Rendering filteredAndSortedPrompts:", filteredAndSortedPrompts) ||
            filteredAndSortedPrompts.map((p, i) => {
              const sp = getSP(context);
              const title = (p?.title || p?.Title || "").trim() || "Untitled Prompt";
              const desc = (p?.desc || p?.Description || "").trim() || "No description available.";
              const promptText = p?.prompt || p?.Prompt || "";
              const category = p?.categories || p?.Categories || "Uncategorized";
              const tips = p?.tips || p?.TIPS || "Not Provided";
              const roiLabel = p?.roi || p?.ROI || "Not Provided";
              if(roiLabel === "$")
              {
                roiLabel = "$ - Low Impact";
              }
              else if(roiLabel === "$$")
              {
                roiLabel = "$$ - Medium Impact";
              }
              else if(roiLabel === "$$$")
              {
                roiLabel = "$$$ - High Impact";
              }
              const ets = p?.ets || p?.ETS || "Not Provided";
              const author = p?.author || p?.Author?.Title || "Unknown";
              const rawDate = p?.date || p?.Created;
              const date = rawDate
                ? new Date(rawDate).toLocaleDateString("en-US", {
                    month: "2-digit",
                    day: "2-digit",
                    year: "numeric"
                  })
                : "-";
              const status = p?.status || p?.Status || "Pending";
              const itemId = p?.Id || p?.ID || p?.id;
              const id = (p?.Id || p?.id || p?.ID)?.toString();
              const likeInfo = likesState[id] || {
                liked: false,
                count: Number(p?.LikesCount) || 0,
              };
              const shareCount = p?.SharingCount || 0;
              const copyCount = copyState[itemId] || 0;
              const toggleLike = async () => {
               const cur = likesState[id] || { liked: false, count: 0 };
               const newLiked = !cur.liked;
               const newCount = newLiked ? cur.count + 1 : Math.max(0, cur.count - 1);
               setLikesState(prev => ({
               ...prev,
               [id]: { liked: newLiked, count: newCount },
              }));

                try {
                  await updateLikeInSharePoint(itemId, newCount);
                  const currentUser = context.pageContext.user.email || context.pageContext.user.loginName;
                  await updateUserPromptSummaryOnLike(currentUser, itemId, newLiked); 
                  const logListName = configItems?.LogsListName || "UserActivityLog";
                  await ensureUserActivityLogList(sp, logListName);
                  await addOrUpdateUserActivityLog(sp, logListName, currentUser, itemId, newLiked ? "Like" : "Unlike");
                } catch (err) {
                  console.error("Error updating like in SharePoint:", err);
                }
              };
              const toggleFav = async () => {
               const isFav = !!favState[id];
               const newFav = !isFav;
               setFavState(prev => ({
                  ...prev,
                  [id]: newFav
                }));

                try {
                  const currentUser = context.pageContext.user.email || context.pageContext.user.loginName;
                  await updateUserPromptSummaryOnFavorite(currentUser, itemId, newFav); 
                  const logListName = configItems?.LogsListName || "UserActivityLog";
                  await ensureUserActivityLogList(sp, logListName);
                  await addOrUpdateUserActivityLog(sp, logListName, currentUser, itemId, newFav ? "Favorite" : "UnFavorite");
                } catch (err) {
                  console.error("Error updating favorite in SharePoint:", err);
                  setFavState(prev => ({
                    ...prev,
                    [id]: isFav
                  }));
                }
              };
              const statusClass =
                status === "Approved"
                  ? styles.approved
                  : status === "In Review"
                  ? styles.pending
                  : styles.pending;
              return (
               <div className={styles.promptData}>
                  <div className={styles.leftColumn}>
                    <div className={styles.promptTitle}>{title}</div>
                    <div className={styles.sectionTitle}>Prompt Description:<span className={styles.promptDescription}> {desc}</span></div>                   
                    <div className={styles.footerActions}>
                      <span
                        className={styles.footerItem}
                        onClick={() => handleCopyItem(p)}
                      >
                        <CopyRegular aria-label="Copy" className={styles.footerIcon} /> Copy<sup className={styles.copySup}>{copyCount}</sup>
                      </span>

                      <span className={`${styles.footerItem} ${favState[id] ? styles.favorited : ""}`} onClick={toggleFav}>
                        <TagRegular aria-label="Tag" className={styles.footerIcon} />
                        {favState[id] ? "Saved" : "Save"}
                      </span>
                      <span
                        className={`${styles.footerItem} ${
                          likeInfo.liked ? styles.liked : ""
                        }`}
                        onClick={toggleLike}
                      >
                        <ThumbLikeRegular area-label="Like"
                            className={styles.footerIcon}
                            primaryFill="#605e5c"
                          /> Like <sup className={styles.copySup}>{likeInfo.count}</sup>
                      </span>
                    </div>
                  </div>
                  <div className={styles.rightColumn}>
                    <div className={styles.headerMeta}>
                      <span className={styles.roi}>
                        ROI: {roiLabel}
                      </span>
                      <span className={styles.timeSaved}>
                        Estimated Time Saved: {ets}
                      </span>
                      <span className={styles.categoryBadge}>
                        {category}
                      </span>
                    </div>
                    <div className={styles.promptBox}>
                      <ExpandUpRightRegular area-label="View full screen"
                        className={styles.expandIcon}
                        title="View full screen"
                        onClick={() => setSelectedPrompt(p)}
                      />
                      <span className={styles.sectionTitle}>Prompt:</span> {promptText}
                      </div>                   
                    {tips && (
                      <div className={styles.tipsSection}>
                        <div
                          className={styles.tipsToggle}
                          onClick={() =>
                            setExpandedTipsId(expandedTipsId === p.Id ? null : p.Id)
                          }
                        >
                          {expandedTipsId === p.Id ? "Hide Tips ▲" : "Show Tips ▼"}
                        </div>
                        {expandedTipsId === p.Id && (
                          <div className={styles.tipsText}>
                            <span className={styles.sectionTitle}>Tips for Best Results: </span>{tips}
                          </div>
                        )}
                      </div>
                    )}
                    <div className={styles.createdBy}>
                      Created by {author} on {date}
                    </div>
                  </div>
                    <Dialog
                      open={!!selectedPrompt}
                      modalType="modal"
                      onOpenChange={(e, data) => {
                        if (!data.open) setSelectedPrompt(null);
                      }}
                    >
                      <DialogSurface className={styles.fullScreenDialog}>
                        <DialogBody className={styles.dialogBody}>
                          <DismissRegular area-label="Close"
                            className={styles.dialogClose}
                            onClick={() => setSelectedPrompt(null)}
                          />

                          {selectedPrompt && (
                            <>
                              <div className={styles.dialogSection}>                                  
                                <div className={styles.dialogContent}>
                                  <span className={styles.dialogTitle}>Prompt: </span> {selectedPrompt.Prompt}
                                </div>
                              </div>
                              {selectedPrompt.TIPS && (
                                <div className={styles.dialogSection}>
                                  <div className={styles.dialogContent}>
                                    <span className={styles.dialogTitle}>Tips for Best Results: </span>{selectedPrompt.TIPS}
                                  </div>
                                </div>
                              )}
                            </>
                          )}
                        </DialogBody>
                      </DialogSurface>
                    </Dialog>
                </div>              
              );
            })            
          )}           
        </div>
      </div>
) : ( 
  <div className={styles.emptyFormContainer}>
    <div className={styles.formHeader}>
      <Button
        icon={<ArrowLeftRegular aria-label="Back" />}
        appearance="subtle"
        onClick={() => {
          resetForm();
          setShowSubmitForm(false);
        }}

      >
        Back
      </Button>
      <div className={styles.formActions}>
        <Button
          appearance="secondary"
          onClick={() => {
            resetForm();
            setShowSubmitForm(false);
          }}

        >
          Cancel
        </Button>
        <Button
          appearance="primary"
          className={styles.submitButton}
          onClick={() => handleSubmitPrompt()}
        >
          Submit Prompt
        </Button>
      </div>
    </div>

    <div className={styles.formBody}>      
      <div className={styles.formRow}>
        <div className={styles.formColumn}>
          <label className={styles.fieldLabel}>App <span style={{ color: "red" }}>*</span></label>
          <select className={styles.fieldDropdown} value={formData.app || (pcategories?.[0]?.title || "")}
            onChange={(e) => setFormData({ ...formData, app: e.target.value })}>                        
            {pcategories?.map((cat, index) => (
                <option key={index} value={cat.title}>
                  {cat.title}
                </option>
              ))}
          </select>
          <label className={styles.fieldLabel}>Title <span style={{ color: "red" }}>*</span></label>
          <input
            type="text"
            className={styles.fieldInput}
            placeholder="Enter a descriptive title for your prompt"
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          />
          <label className={styles.fieldLabel}>Category <span style={{ color: "red" }}>*</span></label>
          <select className={styles.fieldDropdown} value={formData.category || "Select a Category"}
            onChange={(e) =>
              setFormData({
                ...formData,
                category:
                  e.target.value === "Select a Category" ? "" : e.target.value
              })
            }
          >
            {categoryTitles.map((title, index) => (
              <option key={index} value={title}>
                {title}
              </option>
            ))}
          </select>
          <label className={styles.fieldLabel}>Description <span style={{ color: "red" }}>*</span></label>
          <textarea
            className={styles.textArea}
            placeholder="Describe what this prompt does and when to use it"
            onChange={(e) => setFormData({ ...formData, desc: e.target.value })}
            rows={4}
          />
          <label className={styles.fieldLabel}>Prompt <span style={{ color: "red" }}>*</span></label>
          <textarea
            className={styles.textArea}
            placeholder="Enter your AI prompt here"
            onChange={(e) => setFormData({ ...formData, prompt: e.target.value })}
            rows={6}
          />
          {/*Attach supporting files 
          <label className={styles.fieldLabel}>Attach supporting files</label>
          <div
            className={styles.fileUploadBox}
            onClick={() => document.getElementById("fileUpload").click()}
          >
            <AttachRegular className={styles.fileIcon} />
            <span className={styles.fileText}>Add file</span>
            <input
              type="file"
              id="fileUpload"
              className={styles.hiddenFileInput}
              multiple
              onChange={(e) => setFormData({ ...formData, attachFiles: Array.from(e.target.files) })}
            />
          </div>*/}
          {/*File list preview */}
          {formData.attachFiles && formData.attachFiles.length > 0 && (
            <ul className={styles.fileList}>
              {formData.attachFiles.map((file, index) => (
                <li key={index} className={styles.fileItem}>
                  📎 {file.name} <span className={styles.fileSize}>({(file.size / 1024).toFixed(1)} KB)</span>
                </li>
              ))}
            </ul>
          )}
          {configItems?.PromptVisibility?.toLowerCase() === "true" && (
          <>
            <label className={styles.fieldLabel}>Prompt Visibility <span style={{ color: "red" }}>*</span></label>
              <RadioGroup
                layout="horizontal"
                value={formData.promptVisibility}
                onChange={(e, data) =>
                  setFormData((prev) => ({
                    ...prev,
                    promptVisibility: data.value,
                    departments: data.value === "Department" ? prev.departments : ""
                  }))
                }
                className={styles.fieldRadioGroup}
              >
                <Radio value="Everyone" label="Everyone" />
                <Radio value="Department" label="Department" />
              </RadioGroup>
            {formData.promptVisibility === "Department" && (
              <>
                <label className={styles.fieldLabel}>Tag Departments <span style={{ color: "red" }}>*</span></label>          
                <Dropdown                                
                  placeholder="Select departments"
                  className={styles.fieldDropdown}             
                  selectedOptions={formData.departments ? formData.departments.split(";") : []}  
                  value={formData.departments} 
                  onOptionSelect={(e, data) => {                 
                      setFormData(prev => ({
                        ...prev,
                        departments: (data.selectedOptions as string[]).join(";"),
                      }));                 
                  }}
                >
                  {deptOptions?.length > 0 ? (
                    deptOptions.map((cat, index) => (
                      <Option key={index} value={cat.title}>
                        {cat.title}
                      </Option>
                    ))
                  ) : (
                    <Option disabled>No tags found</Option>
                  )}
                </Dropdown>
                </>     
            )}
          </>
        )}
        </div>
        <div className={styles.formColumn}>
          <label className={styles.fieldLabel}>Tips for Best Results</label>
          <input
            type="text"
            className={styles.fieldInput}
            placeholder="Enter your device"
            onChange={(e) => setFormData({ ...formData, tips: e.target.value })}
          />
          <label className={styles.fieldLabel}>ROI Impact Tier</label>
          <select
            className={styles.fieldDropdown}
            value={formData.roi || ""}
            onChange={(e) =>
              setFormData({ ...formData, roi: e.target.value })
            }
          >
            <option value="">Select tier</option>
            <option value="$">Low Impact</option>
            <option value="$$">Medium Impact</option>
            <option value="$$$">High Impact</option>
          </select>
          <label className={styles.fieldLabel}>Estimated Time Saved</label>
          <div className={styles.inlineDropdowns}>
            <select
              className={styles.fieldDropdown}
              value={days}
              onChange={(e) => setDays(e.target.value)}
            >
              <option value="">Days</option>
              {[...Array(31)].map((_, i) => (
                <option key={i} value={i}>{i}</option>
              ))}
            </select>
            <select
              className={styles.fieldDropdown}
              value={hours}
              onChange={(e) => setHours(e.target.value)}
            >
              <option value="">Hours</option>
              {[...Array(24)].map((_, i) => (
                <option key={i} value={i}>{i}</option>
              ))}
            </select>
            <select
              className={styles.fieldDropdown}
              value={minutes}
              onChange={(e) => setMinutes(e.target.value)}
            >
              <option value="">Minutes</option>
              {[0, 15, 30, 45].map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
          {/*<label className={styles.fieldLabel}>Add an image to represent your prompt</label>

          <div
            className={styles.imageUploadBox}
            onClick={() => document.getElementById("imageUpload").click()}
          >
            <div className={styles.imageIconBox}>
              <img
                src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='white'><path d='M4 5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm2 0v14h12V5zm6 4a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM8 15l2.5-3 2.5 3h5v2H8z'/></svg>"
                alt="upload icon"
                className={styles.imageIcon}
              />
            </div>
            <span className={styles.imageText}><ArrowUploadRegular/>Add an image</span>
            <input
              type="file"
              id="imageUpload"
              accept="image/*"
              className={styles.hiddenFileInput}
              onChange={(e) =>
                setFormData({ ...formData, imageFile: e.target.files?.[0] || null })
              }
            />            
          </div>
              {formData.imageFile && (
              <ul className={styles.fileList}>
                <li className={styles.fileItem}>
                  {formData.imageFile.name}{" "}
                  <span className={styles.fileSize}>
                    ({(formData.imageFile.size / 1024).toFixed(1)} KB)
                  </span>
                </li>
              </ul>
              )}*/}
        </div>
      </div>
    </div>   
  </div>
)}
    </div>
  );
}
