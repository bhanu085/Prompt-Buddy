
require("./PromptSidebar.module.css");
const styles = {
  sidebar: 'sidebar_2f08ddc7',
  submitButton: 'submitButton_2f08ddc7',
  categoryList: 'categoryList_2f08ddc7',
  categoryItem: 'categoryItem_2f08ddc7',
  categoryLeft: 'categoryLeft_2f08ddc7',
  countBadge: 'countBadge_2f08ddc7',
  active: 'active_2f08ddc7',
  label: 'label_2f08ddc7',
  iconBox: 'iconBox_2f08ddc7',
  iconCopilotM365: 'iconCopilotM365_2f08ddc7',
  iconCopilotWeb: 'iconCopilotWeb_2f08ddc7',
  iconDesigner: 'iconDesigner_2f08ddc7',
  iconExcel: 'iconExcel_2f08ddc7',
  iconForms: 'iconForms_2f08ddc7',
  iconLoop: 'iconLoop_2f08ddc7',
  iconOneNote: 'iconOneNote_2f08ddc7',
  iconOutlook: 'iconOutlook_2f08ddc7',
  iconPowerApps: 'iconPowerApps_2f08ddc7',
  iconPowerAutomate: 'iconPowerAutomate_2f08ddc7',
  iconPowerPoint: 'iconPowerPoint_2f08ddc7',
  iconTeams: 'iconTeams_2f08ddc7',
  iconViva: 'iconViva_2f08ddc7',
  iconWhiteboard: 'iconWhiteboard_2f08ddc7',
  submitTitle: 'submitTitle_2f08ddc7'
};

export default styles;
