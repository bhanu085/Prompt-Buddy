
require("./PromptBuddy.module.css");
const styles = {
  root: 'root_87b17d50',
  container: 'container_87b17d50',
  section: 'section_87b17d50',
  header: 'header_87b17d50',
  itemRow: 'itemRow_87b17d50',
  left: 'left_87b17d50',
  name: 'name_87b17d50',
  title: 'title_87b17d50',
  count: 'count_87b17d50',
  toolbar: 'toolbar_87b17d50',
  toolbarItem: 'toolbarItem_87b17d50',
  searchBar: 'searchBar_87b17d50',
  searchInput: 'searchInput_87b17d50',
  goButton: 'goButton_87b17d50',
  cardGrid: 'cardGrid_87b17d50',
  cardWrapper: 'cardWrapper_87b17d50',
  card: 'card_87b17d50',
  cardOverlay: 'cardOverlay_87b17d50',
  cardInner: 'cardInner_87b17d50',
  cardIcon: 'cardIcon_87b17d50',
  cardTitle: 'cardTitle_87b17d50',
  cardDesc: 'cardDesc_87b17d50',
  cardCount: 'cardCount_87b17d50',
  pageTitleWrapper: 'pageTitleWrapper_87b17d50',
  pageTitleIcon: 'pageTitleIcon_87b17d50',
  pageTitleText: 'pageTitleText_87b17d50',
  promptBuddy: 'promptBuddy_87b17d50',
  welcome: 'welcome_87b17d50',
  welcomeImage: 'welcomeImage_87b17d50',
  links: 'links_87b17d50',
  active: 'active_87b17d50',
  contributorAvatar: 'contributorAvatar_87b17d50'
};

export default styles;
