/// <reference types="react" />
import type { IPromptBuddyProps } from "./IPromptBuddyProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
export default function PromptBuddy(props: IPromptBuddyProps): JSX.Element;
//# sourceMappingURL=PromptBuddy.d.ts.map