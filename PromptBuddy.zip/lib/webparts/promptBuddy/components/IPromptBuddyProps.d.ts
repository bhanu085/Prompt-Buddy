import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IPromptBuddyProps {
    context: WebPartContext;
}
//# sourceMappingURL=IPromptBuddyProps.d.ts.map