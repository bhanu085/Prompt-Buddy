declare const styles: {
    sidebar: string;
    submitButton: string;
    categoryList: string;
    categoryItem: string;
    categoryLeft: string;
    countBadge: string;
    active: string;
    label: string;
    iconBox: string;
    iconCopilotM365: string;
    iconCopilotWeb: string;
    iconDesigner: string;
    iconExcel: string;
    iconForms: string;
    iconLoop: string;
    iconOneNote: string;
    iconOutlook: string;
    iconPowerApps: string;
    iconPowerAutomate: string;
    iconPowerPoint: string;
    iconTeams: string;
    iconViva: string;
    iconWhiteboard: string;
    submitTitle: string;
};
export default styles;
//# sourceMappingURL=PromptSidebar.module.scss.d.ts.map