/// <reference types="react" />
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/fields";
import "@pnp/sp/site-users/web";
import "@pnp/sp/profiles";
import "@pnp/graph/teams";
export default function PromptDetails({ context, category, configItems, pcategories, promptCategories, categories, prompts, departments, personas, onBack }: {
    context: any;
    category: any;
    configItems: any;
    pcategories: any;
    promptCategories: any;
    categories: any;
    prompts: any;
    departments: any;
    personas: any;
    onBack: any;
}): JSX.Element;
//# sourceMappingURL=PromptDetails.d.ts.map