/// <reference types="react" />
export default function PromptSidebar({ promptCategories, ShowSubmitButton, selectedCategory, onSelectCategory, onSubmitPrompt, showSubmitForm }: {
    promptCategories: any;
    ShowSubmitButton: any;
    selectedCategory: any;
    onSelectCategory: any;
    onSubmitPrompt: any;
    showSubmitForm: any;
}): JSX.Element;
//# sourceMappingURL=PromptSidebar.d.ts.map